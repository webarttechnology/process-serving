<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
    <!----------Custom CSS------------>
    <link rel="stylesheet" href="{{ asset('css/login.css') }}">
</head>

<body>
    <section class="registrsecty loginscty py-5">
        <div class="container">
            <div class="row g-0 align-items-center">
                <div class="col-md-4">
                    <div class="lftprt">
                        <div>
                            <h2>Create your Account</h2>
                            <p>To keep track on your dashboard please login with your personal info.</p>
                            <div class="btnprt mt-4">
                                <a href="https://countrywideprocess.com/new/user-information-register"
                                    class="lgmnbtn">Register</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 text-center">
                    <div class="rghtprt d-flex flex-column justify-content-center">
                        <h2>Change Your Password</h2>

                        <div class="cform mt-4">
                            <form method="POST" action="{{ url('change-password-action') }}">
                                @csrf

                                <input type="hidden" name="verifyCode" value="{{ $verifyCode }}">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="mb-3 material-textfield">
                                            <input type="password" id="password" name="password" required>
                                            <label for="">Password</label>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="mb-3 material-textfield">
                                            <input type="password" id="password" name="confirm_password" required>
                                            <label for="">Confirm Password</label>
                                        </div>
                                    </div>
                                </div>
                                @if (null != session('error'))
                                    <div class="alert alert-danger fade show pe-5" role="alert">
                                        <span class="badge rounded-pill badge-danger shadow-100">Error</span>
                                        &nbsp; {{ session('error') }}
                                    </div>
                                @endif
                                @if (null != session('success'))
                                    <div class="alert alert-success  fade show pe-5" role="alert">
                                        <span class="badge rounded-pill badge-success shadow-100">Success</span>
                                        &nbsp; {{ session('success') }}
                                    </div>
                                @endif
                                @if (null != session('warning'))
                                    <div class="alert alert-warning fade show pe-5" role="alert">
                                        <span class="badge rounded-pill badge-warning shadow-100">Warning</span>
                                        {{ session('warning') }}
                                    </div>
                                @endif
                                <a href="{{ url('/') }}">Remember your password? Login Now</a>
                                <div class="actnbtns mt-5">
                                    <ul>
                                        <li><button type="submit" href="javascript:void(0)"
                                                class="penqbtn">Save</button></li>
                                        <!-- <li><a href="javascript:void(0)" class="penqbtn">Next</a></li> -->
                                    </ul>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</body>

</html>
